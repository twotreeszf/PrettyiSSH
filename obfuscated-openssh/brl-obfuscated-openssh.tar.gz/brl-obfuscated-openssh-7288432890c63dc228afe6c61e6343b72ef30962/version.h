/* $OpenBSD: version.h,v 1.55 2009/02/23 00:06:15 djm Exp $ */

#define SSH_VERSION	"OpenSSH_5.2"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
